#!/usr/bin/env python3
"""GameVox additive FREE-VOICE baseline patch.

Apply to the CURRENT GameVox project (never overwrite with an older ZIP).
This only switches GameVox to the user's chosen Android system TTS engine,
blocks paid TTS providers in the speak path, and prevents network voice forcing.
It does NOT bundle model binaries or certify runtime compatibility.
"""
from pathlib import Path
import argparse
import shutil
import sys

REL = Path('app/src/main/java/com/example/service/ForegroundTtsManager.kt')
PATCH_TAG = 'GAMEVOX_FREE_LOCAL_TTS_V1'


def patch(root: Path) -> Path:
    source = root / REL
    if not source.is_file():
        raise RuntimeError(f'Could not locate {REL} under {root}. Use the Android project root.')
    data = source.read_text(encoding='utf-8')
    if PATCH_TAG in data:
        print('Already patched; no changes applied.')
        return source
    replacements = [
        (
            '        const val GOOGLE_TTS_PACKAGE = "com.google.android.tts"',
            '        const val GOOGLE_TTS_PACKAGE = "com.google.android.tts"\n'
            '        private const val ' + PATCH_TAG + ' = true // never invoke paid voice APIs',
            'add free-voice guard',
        ),
        (
            '''            tts = TextToSpeech(
                appContext,
                createTtsInitListener(isGoogleEngineAttempt = true),
                GOOGLE_TTS_PACKAGE
            )''',
            '''            // Use Android's user-selected default TTS engine. This permits a
            // free on-device sherpa-onnx/Supertonic TTS engine, if installed.
            tts = TextToSpeech(
                appContext,
                createTtsInitListener(isGoogleEngineAttempt = false)
            )''',
            'prefer selected system TTS engine',
        ),
        (
            'if (state.cloudTtsProvider != CloudTtsProvider.ANDROID_SSML_NETWORK) {',
            'if (!' + PATCH_TAG + ' && state.cloudTtsProvider != CloudTtsProvider.ANDROID_SSML_NETWORK) {',
            'block all paid/cloud TTS calls',
        ),
        (
            '''            allowNetworkSynthesis = state.useHighQualityNetworkVoice,
            allowSsml = state.ssmlEnabledOnDevice,''',
            '''            allowNetworkSynthesis = false, // forbid network synthesis
            allowSsml = false,           // on-device engines take plain text''',
            'force plain-text offline TTS',
        ),
        (
            '''        // Trigger background neural voice pack warm-up & watcher automatically''',
            '''        // Never warm up a network voice when free/offline mode is active.
                // Trigger background neural voice pack warm-up & watcher automatically''',
            'document missing-pack behavior',
        ),
    ]
    for old, new, explanation in replacements:
        count = data.count(old)
        if count != 1:
            raise RuntimeError(f'Patch precondition failed: {explanation}. Expected one match; found {count}. NO files changed.')
        data = data.replace(old, new, 1)
    # Disables automatic network warmup independently of UI settings.
    old = '''    private fun triggerSilentAsyncVoicePackWarmup(engine: TextToSpeech, targetLang: TargetLanguage) {
        if (isSpeakingNow()) return'''
    new = '''    private fun triggerSilentAsyncVoicePackWarmup(engine: TextToSpeech, targetLang: TargetLanguage) {
        if (''' + PATCH_TAG + ''') return
        if (isSpeakingNow()) return'''
    if data.count(old) != 1:
        raise RuntimeError('Patch precondition failed: voice-pack warmup guard. NO files changed.')
    data = data.replace(old, new, 1)
    # Exclude network voices from installed voice selection if possible.
    old = '''            preferNetworkVoice = state.useHighQualityNetworkVoice'''
    if data.count(old) < 1:
        raise RuntimeError('Patch precondition failed: voice selection. NO files changed.')
    data = data.replace(old, '            preferNetworkVoice = false')
    # Avoid selecting a network voice even if it exists in catalog.
    old = '''        val chosenVoice = (if (state.useHighQualityNetworkVoice) {'''
    if data.count(old) != 1:
        raise RuntimeError('Patch precondition failed: catalog choice. NO files changed.')
    data = data.replace(old, '        val chosenVoice = (if (!' + PATCH_TAG + ' && state.useHighQualityNetworkVoice) {', 1)
    old = '''        populateGenderVoiceCatalog(engine, targetLang, preferNetworkVoice = state.useHighQualityNetworkVoice)'''
    if data.count(old) != 1:
        raise RuntimeError('Patch precondition failed: gender catalog. NO files changed.')
    data = data.replace(old, '        populateGenderVoiceCatalog(engine, targetLang, preferNetworkVoice = false)', 1)
    backup = source.with_suffix('.kt.before_free_voice_patch')
    shutil.copy2(source, backup)
    source.write_text(data, encoding='utf-8')
    print(f'Patched: {source}\nBackup:  {backup}')
    return source


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('project_root', help='Android project root containing app/')
    args = ap.parse_args()
    try:
        patch(Path(args.project_root).resolve())
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(1)
