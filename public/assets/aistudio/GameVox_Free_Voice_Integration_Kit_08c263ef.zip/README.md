# GameVox — Free neural Hindi voice integration kit (14 Nov 2026)

## What was actually inspected

The attached `GameVox-main.zip` (older baseline, dated 13 Nov 2026) uses native Android Kotlin. Its `ForegroundTtsManager.initializeAsync()` explicitly constructs `TextToSpeech(..., GOOGLE_TTS_PACKAGE)` with `GOOGLE_TTS_PACKAGE = "com.google.android.tts"`. Therefore changing Android's preferred TTS to a free sherpa-onnx engine **will not switch GameVox** until that hardcoding is removed. The more recent AI Studio P0–P2 repaired source was NOT provided, so do **not** replace it with the old ZIP.

## The first practical integration: Android system TextToSpeech engine

An official **sherpa-onnx Supertonic 3 Hindi Android TTS Engine APK** exists for arm64-v8a. It exposes text-to-speech through Android TTS APIs and allows offline speech synthesis with Supertonic 3. Start here: no custom ONNX native library bundled into GameVox, and no cloud/API calls required for voice generation after installation.

Official download and demo: https://k2-fsa.github.io/sherpa/onnx/tts/all/Hindi/supertonic-3-hi.html (expand **Android APK**, select **arm64-v8a**). Verify package provenance before installing the APK, and only install the official artifact.

1. Install official Supertonic 3 sherpa-onnx TTS Engine APK on the Android phone.
2. Android Settings > search **Text-to-speech output** or **Preferred engine** > choose the installed sherpa-onnx TTS engine. Menus vary by manufacturer.
3. Test a natural Hindi sentence in the engine's preview if it provides one. Select Hindi and male/female voice presets if exposed in its UI. A speaker-id choice might not be exposed as separate Android `Voice` entries: test rather than assuming GameVox can switch speakers automatically.
4. On the **LATEST** GameVox Android project, let `ForegroundTtsManager` use Android's default TTS engine instead of forcing `com.google.android.tts`.
5. Keep plain Hindi input and no SSML, disable paid/cloud providers and avoid `KEY_FEATURE_NETWORK_SYNTHESIS`. Make the active engine package and chosen voice visible on the diagnosis screen.
6. Test in a landscape game with an OCR subtitle, and verify captured English -> Hindi -> utterance `onStart` -> audible Hindi.

### Optional minimal code patch

`apply_free_voice_patch.py` is a narrowly scoped patch of the **older observed ForegroundTtsManager.kt contract**. Run it at the root of the LATEST Android project (contains `app/`). The script fails without changing files if expected patterns differ. It saves a backup and does not touch translation, OCR, MediaProjection, or the other P0–P2 changes:

```sh
python apply_free_voice_patch.py /path/to/latest/GameVox-main
```

This patch is **not** a build-verified fix. Review the diff, especially voice detection and diagnosis labels; verify no paid provider is referenced in *other* TTS call paths. It is only phase 1. Remove or hide paid provider configuration in UI in the later full integration; retain migration support so existing settings do not crash.

## Second option: Kokoro-82M via official MediaPipe Android API

Official Google Android documentation supports the Kokoro-82M on-device model as a `.litertlm` bundle, Hindi language, voice selection, and streaming synthesis. It is **not** a sherpa-onnx Android TTS engine install by default. To integrate it directly, a native `MediaPipeKokoroVoiceEngine` adapter must handle model download, `TextToSpeech` API, `AudioTrack`, cancellation, and memory. The bundled `kokoro_int8_gpu_fp16.litertlm` is ~295 MB. Its actual runtime latency and sound quality must be measured on the phone. Avoid implementing it until you have baseline figures for the simpler Supertonic system-TTS route.

Refs: https://developers.google.com/edge/mediapipe/solutions/audio/text_to_speech/index and https://github.com/google-ai-edge/mediapipe-samples/blob/main/examples/text_to_speech/android/README.md

## Supertonic direct embedding later (if Android TTS bridge is too limiting)

Sherpa-ONNX has an actual Kotlin `OfflineTtsSupertonicModelConfig` and `OfflineTts.generateWithConfigAndCallback` API. The Hindi `GenerationConfig` should specify `extra = mapOf("lang" to "hi")`, `sid` 0..9, `numSteps` measured at e.g. 5 vs 8, and playback through `AudioTrack` with stream stop/cancel support. This requires copying the native shared libraries, downloading and verifying the ONNX files plus `tts.json`, `unicode_indexer.bin`, `voice.bin`, ensuring arm64 ABI, a dedicated background thread, lifecycle cleanup, and licenses. **Do not** assume embedding VoiceStudio.sh's full desktop code is the correct route.

Docs: https://k2-fsa.github.io/sherpa/onnx/tts/supertonic.html and https://k2-fsa.github.io/sherpa/onnx/android/build-sherpa-onnx.html

## Benchmark target (not achieved/verified)

Test three representative short Hindi dialogue lines, each female/male voice option:

- शांत: "डरो मत जेनी, मैं यहीं हूँ।"
- डर: "प्लीज़ जल्दी आओ! मुझे बहुत डर लग रहा है!"
- गुस्सा: "मैंने कहा ना, मुझसे दूर रहो!"

Run 10 warm trials per engine after 3 cold starts. In each trial record: `OCR detected timestamp`, `translation ready`, `TTS requested`, `UtteranceProgressListener.onStart` or first PCM audio write timestamp, `onDone`, plus total duration, CPU/RAM and game FPS. Measure subtitle-to-audio delay (`firstAudioTimeMs - subtitleDetectedMs`) and TTS request-to-audio (`firstAudioTimeMs - ttsRequestMs`) separately, and report median and p95. Target: <=1.5 seconds subtitle-to-audio p50 only if actual game tests support it. Reject any engine whose voice is unintelligible, misses speech, repeatedly pronounces names wrong, or harms game frame rates.

**Important:** `UtteranceProgressListener.onStart` is an approximation, not proof of when acoustic output actually becomes audible. For exact first-audible latency, record PCM playback or loopback microphone data on a test device (outside a running game if needed). Without a physical phone, actual timings cannot be measured.

## Test checklist

- [ ] Official Supertonic Hindi APK installed and listed as an Android TTS engine
- [ ] Android system TTS test actually speaks Hindi with that engine
- [ ] Latest GameVox compiled after changing preferred TTS engine selection
- [ ] GameVox diagnosis shows active engine package, Hindi voice, and onStart/onDone
- [ ] Male and female voices genuinely distinct; if not, mark as unsupported, never fake it by changing pitch alone
- [ ] OCR subtitle recognized and spoken in live game, not only a manual sample test
- [ ] Duplicate subtitles skipped, stop prevents stale voice, rotation remains stable
- [ ] No paid voice APIs invoked and no keys required
- [ ] 3 cold + 10 warm runs / voice profile, median + p95 timings, game FPS and RAM logged
- [ ] If first route underperforms, add official Kokoro MediaPipe adapter behind feature flag and repeat benchmark

## Verification status

- Source inspection: COMPLETED for older ZIP only.
- Official support/source documentation: VERIFIED.
- Patch dry run: PASSED against older ZIP; no Android compiler run.
- Latest AI Studio P0–P2 source: NOT AVAILABLE.
- APK compilation: NOT RUN.
- On-device Hindi quality and performance: NOT MEASURED.
