package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.data.DubbingDeliveryMode
import com.example.data.PipelineStageTimestamps
import com.example.data.SubtitleAlignmentLogEntry
import com.example.data.SubtitleEvent
import com.example.data.TranslationStyle
import com.example.data.TranslatorStateRepository
import com.example.data.VoiceProfile
import com.example.data.VoiceProfileRepository
import com.example.service.ForegroundTtsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Structured output of capturing a video frame, running ML Kit Text Recognition to extract English
 * subtitle text, and passing the extracted English directly into [HindiTranslationEngine].
 */
data class VideoFrameTranslationResult(
    val extractedEnglish: String,
    val spokenDialogue: String,
    val speakerName: String?,
    val translatedHindi: String,
    val translationSource: String,
    val ocrLatencyMs: Long,
    val translationLatencyMs: Long,
    val preprocessPassUsed: String,
    val skippedUnchangedFrame: Boolean = false
)

/**
 * Process-wide Singleton coordinating:
 * 1. [ImageProcessor] Target Subtitle Region Cropping + Frame-Diff Optimization + Multi-Pass OCR
 * 2. [SubtitleTextFilter] to ignore HUD clutter, health bars, timers, and unrelated game UI text
 * 3. Multi-Speaker Character Detection ([VoiceProfileRepository.resolveSpeakerAndVoiceForSubtitle])
 * 4. Dual-Mode Translation via [HindiTranslationEngine.translateSuspendDetailed] (Offline ML Kit OR Optional AI)
 * 5. [SubtitleDubbingQueue] + [sessionEpoch] cancellation so paused/stopped sessions never speak stale lines
 * 6. [PronunciationGlossary] applied right before Hindi TTS playback via [ForegroundTtsManager].
 */
class OcrTranslationPipeline private constructor(context: Context) {

    private val appContext: Context = context.applicationContext
    private val scanMutex = Mutex()
    private val pipelineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val dubbingQueue = SubtitleDubbingQueue(maxCapacity = 2)
    private val sessionEpoch = AtomicLong(0L)
    private val subtitleSequenceCounter = AtomicLong(0L)

    @Volatile
    private var activeTranslationJob: Job? = null

    companion object {
        val HINDI_LOCALE: Locale = Locale.forLanguageTag("hi-IN")

        @Volatile
        private var INSTANCE: OcrTranslationPipeline? = null

        fun getInstance(context: Context): OcrTranslationPipeline {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: OcrTranslationPipeline(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    val imageProcessor: ImageProcessor by lazy {
        ImageProcessor()
    }

    val ttsManager: ForegroundTtsManager by lazy {
        ForegroundTtsManager.getInstance(appContext).also { manager ->
            manager.onUtteranceCompletedImmediately = {
                drainNextQueuedSubtitleIfAny()
            }
            manager.onThirtySecondPostSpeechDelayCompleted = {
                // Only clear anti-repeat memory if the queue is empty and same line stayed idle for 30s
                if (dubbingQueue.size() == 0) {
                    lastSpokenText = ""
                    lastExtractedNormalized = ""
                    lastExtractedSpeakerContextKey = ""
                }
            }
        }
    }

    @Volatile
    var lastSpokenText: String = ""
        private set

    @Volatile
    private var lastExtractedNormalized: String = ""

    @Volatile
    private var lastExtractedSpeakerContextKey: String = ""

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)

    init {
        VoiceProfileRepository.initialize(appContext)
        initializeTtsAsync()
        ensureTranslationModelDownloaded()
    }

    fun currentEpoch(): Long = sessionEpoch.get()

    fun isTtsSpeakingNow(): Boolean = ttsManager.isSpeakingNow()

    fun initializeTtsAsync() {
        ttsManager.registerTtsDataBroadcastReceiver()
        ttsManager.initializeAsync()
    }

    fun refreshTtsConfiguration() {
        ttsManager.refreshVoiceConfiguration()
    }

    fun ensureTranslationModelDownloaded(downloadIfMissing: Boolean = true) {
        pipelineScope.launch(Dispatchers.IO) {
            val targetLang = TranslatorStateRepository.state.value.targetLanguage
            HindiTranslationEngine.ensureOfflineModelDownloaded(
                targetLanguage = targetLang,
                downloadIfMissing = downloadIfMissing
            )
        }
    }

    /**
     * Immediately halts all pending/in-flight dubbing work when the user pauses or stops scanning:
     * increments [sessionEpoch] so in-flight translation coroutines abort before queuing/speaking,
     * clears [dubbingQueue], and stops TTS audio output cleanly.
     */
    fun stopAndClearQueue() {
        val newEpoch = sessionEpoch.incrementAndGet()
        activeTranslationJob?.cancel()
        activeTranslationJob = null
        dubbingQueue.clear()
        ttsManager.stopSpeaking()
        ttsManager.cancelThirtySecondRepeatTimer()
        TranslatorStateRepository.resetSubtitleSequenceTracking(newEpoch)
        TranslatorStateRepository.updateQueueTelemetry(queuedCount = 0)
    }

    /**
     * Extracts a software [Bitmap] from an [android.media.Image] video frame (`ImageReader`),
     * runs the ML Kit Text Recognition pipeline ([ImageProcessor.extractTextFromOverlayBitmap]),
     * and passes the extracted English text directly to [HindiTranslationEngine].
     */
    suspend fun captureAndTranslateMediaImage(
        image: android.media.Image,
        rotationDegrees: Int = 0,
        excludeOverlayRect: Rect? = null,
        targetRegionScreenRect: Rect? = null,
        rawScreenWidth: Int = 0,
        rawScreenHeight: Int = 0,
        skipIfRegionUnchanged: Boolean = true,
        customImageProcessor: ImageProcessor = imageProcessor
    ): VideoFrameTranslationResult = withContext(Dispatchers.Default) {
        val captureStart = System.currentTimeMillis()
        val frameBitmap = ImageProcessor.extractBitmapFromMediaImage(image)
            ?: return@withContext VideoFrameTranslationResult(
                extractedEnglish = "",
                spokenDialogue = "",
                speakerName = null,
                translatedHindi = "",
                translationSource = "Empty Frame",
                ocrLatencyMs = 0L,
                translationLatencyMs = 0L,
                preprocessPassUsed = "Invalid Image Frame"
            )
        val captureLatency = (System.currentTimeMillis() - captureStart).coerceAtLeast(0L)
        try {
            captureAndTranslateVideoFrame(
                frameBitmap = frameBitmap,
                rotationDegrees = rotationDegrees,
                excludeOverlayRect = excludeOverlayRect,
                targetRegionScreenRect = targetRegionScreenRect,
                rawScreenWidth = rawScreenWidth,
                rawScreenHeight = rawScreenHeight,
                skipIfRegionUnchanged = skipIfRegionUnchanged,
                captureLatencyMs = captureLatency,
                customImageProcessor = customImageProcessor
            )
        } finally {
            if (!frameBitmap.isRecycled) {
                frameBitmap.recycle()
            }
        }
    }

    /**
     * Direct ML Kit Text Recognition -> Hindi Translation pipeline for a captured video frame [frameBitmap]:
     * 1. Crops [frameBitmap] to [targetRegionScreenRect] and runs multi-pass ML Kit OCR via [customImageProcessor].
     * 2. Filters HUD noise ([SubtitleTextFilter]) and resolves speaker identity ([VoiceProfileRepository]).
     * 3. Passes the extracted English dialogue directly to [HindiTranslationEngine.translateSuspendDetailed].
     * 4. Updates [TranslatorStateRepository] diagnostics and returns [VideoFrameTranslationResult].
     */
    suspend fun captureAndTranslateVideoFrame(
        frameBitmap: Bitmap,
        rotationDegrees: Int = 0,
        excludeOverlayRect: Rect? = null,
        targetRegionScreenRect: Rect? = null,
        rawScreenWidth: Int = 0,
        rawScreenHeight: Int = 0,
        skipIfRegionUnchanged: Boolean = false,
        captureLatencyMs: Long = 0L,
        customImageProcessor: ImageProcessor = imageProcessor
    ): VideoFrameTranslationResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val appState = TranslatorStateRepository.state.value

        val extractionResult = customImageProcessor.extractTextFromOverlayBitmap(
            source = frameBitmap,
            enableColorInversion = appState.invertColorsEnabled,
            excludeOverlayRect = excludeOverlayRect,
            targetRegionScreenRect = targetRegionScreenRect,
            rawScreenWidth = rawScreenWidth,
            rawScreenHeight = rawScreenHeight,
            skipIfRegionUnchanged = skipIfRegionUnchanged,
            rotationDegrees = rotationDegrees
        )

        val roiDimensions = "${extractionResult.roiWidth}x${extractionResult.roiHeight} (${extractionResult.preprocessPassUsed})"

        val origThumb = BitmapInverter.createPreviewThumbnail(extractionResult.croppedOriginalBitmap)
        val invThumb = BitmapInverter.createPreviewThumbnail(extractionResult.processedBitmap)
        recycleExtractionBitmaps(
            extractionResult.croppedOriginalBitmap,
            extractionResult.processedBitmap,
            origThumb,
            invThumb
        )
        if (!extractionResult.skippedUnchangedFrame) {
            TranslatorStateRepository.updateFramePreviews(origThumb, invThumb)
        }

        val extractedEnglish = cleanExtractedSubtitle(extractionResult.extractedText)
        if (extractionResult.skippedUnchangedFrame || extractedEnglish.isBlank()) {
            TranslatorStateRepository.updateDiagnosisMetrics(
                captureLatencyMs = captureLatencyMs,
                ocrLatencyMs = extractionResult.ocrLatencyMs,
                roiDimensionsText = roiDimensions
            )
            return@withContext VideoFrameTranslationResult(
                extractedEnglish = "",
                spokenDialogue = "",
                speakerName = null,
                translatedHindi = "",
                translationSource = "Idle",
                ocrLatencyMs = extractionResult.ocrLatencyMs,
                translationLatencyMs = 0L,
                preprocessPassUsed = extractionResult.preprocessPassUsed,
                skippedUnchangedFrame = extractionResult.skippedUnchangedFrame
            )
        }

        val parsedDialogue = VoiceProfileRepository.resolveSpeakerAndVoiceForSubtitle(
            rawSubtitleText = extractionResult.extractedText,
            isFromMediaProjectionOcr = true
        )
        val dialogueToTranslate = parsedDialogue.spokenDialogue.trim().ifBlank { extractedEnglish }
        val detailedTranslation = translateEnglishToHindiDetailed(
            englishText = dialogueToTranslate,
            speakerName = parsedDialogue.speakerName
        )

        val totalMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
        TranslatorStateRepository.updateDiagnosisMetrics(
            captureLatencyMs = captureLatencyMs,
            ocrLatencyMs = extractionResult.ocrLatencyMs,
            translationLatencyMs = detailedTranslation.latencyMs,
            totalPipelineLatencyMs = totalMs + captureLatencyMs,
            roiDimensionsText = roiDimensions,
            translationSourceLabel = detailedTranslation.sourceLabel,
            lastPipelineError = detailedTranslation.error.orEmpty()
        )
        if (detailedTranslation.translatedText.isNotBlank()) {
            TranslatorStateRepository.recordTranslationResult(
                english = dialogueToTranslate,
                hindi = detailedTranslation.translatedText,
                wasSpoken = false,
                skippedReason = detailedTranslation.sourceLabel,
                processingTimeMs = totalMs,
                timestamp = timeFormatter.format(Date())
            )
        }

        VideoFrameTranslationResult(
            extractedEnglish = extractedEnglish,
            spokenDialogue = dialogueToTranslate,
            speakerName = parsedDialogue.speakerName,
            translatedHindi = detailedTranslation.translatedText,
            translationSource = detailedTranslation.sourceLabel,
            ocrLatencyMs = extractionResult.ocrLatencyMs,
            translationLatencyMs = detailedTranslation.latencyMs,
            preprocessPassUsed = extractionResult.preprocessPassUsed,
            skippedUnchangedFrame = false
        )
    }

    suspend fun processExtractedRawText(
        rawEnglishText: String,
        enforceActiveSession: Boolean = true,
        frameTimestampMs: Long = System.currentTimeMillis(),
        onDebugTextUpdate: ((english: String, hindi: String, statusNote: String) -> Unit)? = null,
        onAlignedDebugTextUpdate: ((event: SubtitleEvent, hindi: String, statusNote: String) -> Unit)? = null
    ): Pair<String, String> = withContext(Dispatchers.Default) {
        val entryEpoch = sessionEpoch.get()
        scanMutex.withLock {
            if (sessionEpoch.get() != entryEpoch || (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr)) {
                return@withLock "" to ""
            }
            val startTime = System.currentTimeMillis()
            val filtered = SubtitleTextFilter.filterDialogueText(rawEnglishText)
            val extractedEnglish = cleanExtractedSubtitle(filtered)
            if (extractedEnglish.isBlank()) {
                return@withLock "" to ""
            }
            handleExtractedSubtitle(
                rawScanText = filtered,
                extractedEnglish = extractedEnglish,
                startTime = startTime,
                frameTimestampMs = frameTimestampMs,
                entryEpoch = entryEpoch,
                enforceActiveSession = enforceActiveSession,
                captureLatencyMs = 0L,
                ocrLatencyMs = 0L,
                roiDimensionsText = "Accessibility Nodes",
                onDebugTextUpdate = onDebugTextUpdate,
                onAlignedDebugTextUpdate = onAlignedDebugTextUpdate
            )
        }
    }

    suspend fun processCapturedFrame(
        rawBitmap: Bitmap,
        excludeOverlayRect: Rect? = null,
        excludeOverlayRects: List<Rect> = listOfNotNull(excludeOverlayRect),
        targetRegionScreenRect: Rect? = null,
        rawScreenWidth: Int = 0,
        rawScreenHeight: Int = 0,
        skipIfRegionUnchanged: Boolean = true,
        captureLatencyMs: Long = 0L,
        frameTimestampMs: Long = System.currentTimeMillis(),
        enforceActiveSession: Boolean = true,
        rotationDegrees: Int = 0,
        onDebugTextUpdate: ((english: String, hindi: String, statusNote: String) -> Unit)? = null,
        onAlignedDebugTextUpdate: ((event: SubtitleEvent, hindi: String, statusNote: String) -> Unit)? = null
    ): Pair<String, String> = withContext(Dispatchers.Default) {
        val entryEpoch = sessionEpoch.get()
        scanMutex.withLock {
            if (sessionEpoch.get() != entryEpoch || (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr)) {
                return@withLock "" to ""
            }
            val startTime = System.currentTimeMillis()
            val appState = TranslatorStateRepository.state.value

            val extractionResult = try {
                imageProcessor.extractTextFromOverlayBitmap(
                    source = rawBitmap,
                    enableColorInversion = appState.invertColorsEnabled,
                    excludeOverlayRect = excludeOverlayRect,
                    excludeOverlayRects = excludeOverlayRects,
                    targetRegionScreenRect = targetRegionScreenRect,
                    rawScreenWidth = rawScreenWidth,
                    rawScreenHeight = rawScreenHeight,
                    skipIfRegionUnchanged = skipIfRegionUnchanged,
                    rotationDegrees = rotationDegrees
                )
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                TranslatorStateRepository.updateDiagnosisMetrics(
                    captureLatencyMs = captureLatencyMs,
                    lastPipelineError = "OCR error: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
                return@withLock "" to ""
            }

            if (sessionEpoch.get() != entryEpoch || (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr)) {
                recycleExtractionBitmaps(extractionResult.croppedOriginalBitmap, extractionResult.processedBitmap, null, null)
                return@withLock "" to ""
            }

            val roiDimensions = "${extractionResult.roiWidth}x${extractionResult.roiHeight} (${extractionResult.preprocessPassUsed})"

            if (extractionResult.skippedUnchangedFrame) {
                TranslatorStateRepository.updateDiagnosisMetrics(
                    captureLatencyMs = captureLatencyMs,
                    ocrLatencyMs = extractionResult.ocrLatencyMs,
                    roiDimensionsText = roiDimensions
                )
                recycleExtractionBitmaps(extractionResult.croppedOriginalBitmap, extractionResult.processedBitmap, null, null)
                return@withLock "" to ""
            }

            val origThumb = BitmapInverter.createPreviewThumbnail(extractionResult.croppedOriginalBitmap)
            val invThumb = BitmapInverter.createPreviewThumbnail(extractionResult.processedBitmap)
            recycleExtractionBitmaps(
                extractionResult.croppedOriginalBitmap,
                extractionResult.processedBitmap,
                origThumb,
                invThumb
            )
            TranslatorStateRepository.updateFramePreviews(origThumb, invThumb)

            val extractedEnglish = cleanExtractedSubtitle(extractionResult.extractedText)
            if (extractedEnglish.isBlank()) {
                TranslatorStateRepository.updateDiagnosisMetrics(
                    captureLatencyMs = captureLatencyMs,
                    ocrLatencyMs = extractionResult.ocrLatencyMs,
                    totalPipelineLatencyMs = System.currentTimeMillis() - startTime + captureLatencyMs,
                    roiDimensionsText = roiDimensions
                )
                return@withLock "" to ""
            }

            handleExtractedSubtitle(
                rawScanText = extractionResult.extractedText,
                extractedEnglish = extractedEnglish,
                startTime = startTime,
                frameTimestampMs = frameTimestampMs,
                entryEpoch = entryEpoch,
                enforceActiveSession = enforceActiveSession,
                captureLatencyMs = captureLatencyMs,
                ocrLatencyMs = extractionResult.ocrLatencyMs,
                roiDimensionsText = roiDimensions,
                isFromMediaProjectionOcr = true,
                onDebugTextUpdate = onDebugTextUpdate,
                onAlignedDebugTextUpdate = onAlignedDebugTextUpdate
            )
        }
    }

    private fun recycleExtractionBitmaps(
        croppedOriginal: Bitmap?,
        processed: Bitmap?,
        origThumb: Bitmap?,
        invThumb: Bitmap?
    ) {
        try {
            if (croppedOriginal != null &&
                croppedOriginal !== origThumb &&
                croppedOriginal !== invThumb &&
                !croppedOriginal.isRecycled
            ) {
                croppedOriginal.recycle()
            }
        } catch (_: Exception) {
        }
        try {
            if (processed != null &&
                processed !== croppedOriginal &&
                processed !== origThumb &&
                processed !== invThumb &&
                !processed.isRecycled
            ) {
                processed.recycle()
            }
        } catch (_: Exception) {
        }
    }

    private suspend fun handleExtractedSubtitle(
        rawScanText: String,
        extractedEnglish: String,
        startTime: Long,
        frameTimestampMs: Long,
        entryEpoch: Long,
        enforceActiveSession: Boolean,
        captureLatencyMs: Long,
        ocrLatencyMs: Long,
        roiDimensionsText: String,
        isFromMediaProjectionOcr: Boolean = false,
        onDebugTextUpdate: ((english: String, hindi: String, statusNote: String) -> Unit)?,
        onAlignedDebugTextUpdate: ((event: SubtitleEvent, hindi: String, statusNote: String) -> Unit)? = null
    ): Pair<String, String> {
        if (sessionEpoch.get() != entryEpoch || (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr)) {
            return "" to ""
        }

        val state = TranslatorStateRepository.state.value
        val targetLang = state.targetLanguage

        val speakerResolveStart = System.currentTimeMillis()
        val parsedDialogue = VoiceProfileRepository.resolveSpeakerAndVoiceForSubtitle(
            rawSubtitleText = rawScanText,
            isFromMediaProjectionOcr = isFromMediaProjectionOcr
        )
        val speakerResolveMs = (System.currentTimeMillis() - speakerResolveStart).coerceAtLeast(0L)
        val assignedVoice = parsedDialogue.assignedVoice
        val dialogueToTranslate = parsedDialogue.spokenDialogue.trim()
        if (dialogueToTranslate.isBlank()) {
            return "" to ""
        }

        val baseSpeakerContextKey = buildSpeakerContextAntiRepeatKey(
            routeDecision = parsedDialogue.routeDecision,
            characterAssignment = parsedDialogue.characterAssignment,
            speakerName = parsedDialogue.speakerName,
            epoch = entryEpoch
        )
        val candidateSpeakerContextKey = "$baseSpeakerContextKey:${state.translationStyle.code}:${targetLang.code}"

        // Skip re-translating ONLY if extracted dialogue AND speaker/profile/style/game context match the active or most recently queued line
        val candidateNorm = SubtitleDubbingQueue.normalize(dialogueToTranslate)
        if (candidateSpeakerContextKey == lastExtractedSpeakerContextKey &&
            SubtitleDubbingQueue.areSimilar(candidateNorm, lastExtractedNormalized) &&
            !isTtsSpeakingNow()
        ) {
            TranslatorStateRepository.updateDiagnosisMetrics(
                captureLatencyMs = captureLatencyMs,
                ocrLatencyMs = ocrLatencyMs,
                translationLatencyMs = 0L,
                totalPipelineLatencyMs = System.currentTimeMillis() - startTime + captureLatencyMs,
                roiDimensionsText = roiDimensionsText,
                translationSourceLabel = "Anti-Repeat Cache"
            )
            TranslatorStateRepository.recordTranslationResult(
                english = dialogueToTranslate,
                hindi = lastSpokenText.ifBlank { state.lastTranslatedHindi },
                wasSpoken = false,
                skippedReason = "Anti-Repeat: Identical to lastSpokenText",
                processingTimeMs = System.currentTimeMillis() - startTime,
                timestamp = timeFormatter.format(Date())
            )
            return dialogueToTranslate to lastSpokenText
        }

        val seqId = subtitleSequenceCounter.incrementAndGet()
        val gameNs = parsedDialogue.routeDecision?.gameNamespace
            ?: parsedDialogue.characterAssignment?.gameNamespace
            ?: VoiceProfileRepository.getActiveGameNamespace()
        val subtitleEvent = SubtitleEvent(
            eventId = "sub_${entryEpoch}_$seqId",
            sequenceId = seqId,
            sessionEpoch = entryEpoch,
            frameTimestampMs = frameTimestampMs,
            sourceText = rawScanText,
            spokenDialogue = dialogueToTranslate,
            speakerName = parsedDialogue.speakerName,
            gameNamespace = gameNs
        )

        if (state.dubbingDeliveryMode == DubbingDeliveryMode.LIVE_MODE) {
            activeTranslationJob?.cancel()
        }

        val translationResult = translateEnglishToHindiDetailed(
            englishText = dialogueToTranslate,
            speakerName = parsedDialogue.speakerName,
            translationStyle = state.translationStyle,
            gameNamespace = gameNs
        )

        // Enforce strict sequence & epoch ordering: discard stale async translation results
        if (sessionEpoch.get() != entryEpoch ||
            (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr) ||
            (state.dubbingDeliveryMode == DubbingDeliveryMode.LIVE_MODE && seqId < subtitleSequenceCounter.get())
        ) {
            return "" to ""
        }

        val translatedText = translationResult.translatedText
        if (translatedText.isBlank()) {
            TranslatorStateRepository.updateDiagnosisMetrics(
                captureLatencyMs = captureLatencyMs,
                ocrLatencyMs = ocrLatencyMs,
                translationLatencyMs = translationResult.latencyMs,
                totalPipelineLatencyMs = System.currentTimeMillis() - startTime + captureLatencyMs,
                roiDimensionsText = roiDimensionsText,
                translationSourceLabel = translationResult.sourceLabel,
                lastPipelineError = translationResult.error ?: ""
            )
            return "" to ""
        }

        val elapsedMs = System.currentTimeMillis() - startTime
        val timestamp = timeFormatter.format(Date())

        TranslatorStateRepository.updateDiagnosisMetrics(
            captureLatencyMs = captureLatencyMs,
            ocrLatencyMs = ocrLatencyMs,
            translationLatencyMs = translationResult.latencyMs,
            totalPipelineLatencyMs = elapsedMs + captureLatencyMs,
            roiDimensionsText = roiDimensionsText,
            translationSourceLabel = translationResult.sourceLabel,
            lastPipelineError = translationResult.error ?: ""
        )

        val speakerTag = parsedDialogue.speakerName ?: assignedVoice.assignedRole.displayLabel.substringBefore(" (")
        val resolvedSid = parsedDialogue.characterAssignment?.speakerId ?: assignedVoice.engineVoiceIndex
        val finalRouteDecision = parsedDialogue.routeDecision?.copy(
            hindiDialogue = CharacterVoiceRouter.prepareHindiDialogueForSpeech(
                rawHindi = translatedText,
                rawSpeakerTag = parsedDialogue.routeDecision.rawCharacterName,
                assignment = parsedDialogue.characterAssignment
                    ?: parsedDialogue.routeDecision.characterAssignment
            ),
            sessionEpoch = entryEpoch,
            isFromRealMediaProjectionOcr = isFromMediaProjectionOcr
        )
        if (isFromMediaProjectionOcr && finalRouteDecision != null) {
            CharacterVoiceRouter.recordCapturedLiveOcrRoute(finalRouteDecision)
        }
        val queueItem = PendingDubbingItem(
            sourceEnglish = dialogueToTranslate,
            spokenDialogue = dialogueToTranslate,
            translatedText = translatedText,
            voiceProfile = assignedVoice,
            speakerLabel = speakerTag,
            characterAssignment = parsedDialogue.characterAssignment,
            routeDecision = finalRouteDecision,
            sequenceId = seqId,
            eventId = subtitleEvent.eventId,
            frameTimestampMs = frameTimestampMs
        )

        val outcome = dubbingQueue.enqueue(
            item = queueItem,
            isCurrentlySpeaking = isTtsSpeakingNow(),
            activeSpokenEnglishNormalized = lastExtractedNormalized,
            activeSpokenTranslated = lastSpokenText,
            activeSpokenSpeakerContextKey = lastExtractedSpeakerContextKey,
            deliveryMode = state.dubbingDeliveryMode
        )

        val prepEndMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
        TranslatorStateRepository.updateStageTimestamps(
            timestamps = PipelineStageTimestamps(
                subtitleEventId = subtitleEvent.eventId,
                sequenceId = seqId,
                frameCaptureMs = captureLatencyMs,
                ocrMs = ocrLatencyMs,
                speakerResolveMs = speakerResolveMs,
                translationMs = translationResult.latencyMs,
                ttsPrepMs = prepEndMs,
                playbackStartFromFrameMs = (System.currentTimeMillis() - frameTimestampMs).coerceAtLeast(0L),
                ttsGenerationMode = ttsManager.sherpaEngine.lastGenerationModeLabel
            )
        )

        val isVoiceMuted = TranslatorStateRepository.state.value.isVoiceMuted
        var logStatus = "Processed"

        when (outcome) {
            is DubbingEnqueueOutcome.SkippedDuplicate -> {
                logStatus = "Duplicate skipped"
                TranslatorStateRepository.recordTranslationResult(
                    english = dialogueToTranslate,
                    hindi = translatedText,
                    wasSpoken = false,
                    skippedReason = "Anti-Repeat: Identical to lastSpokenText",
                    processingTimeMs = elapsedMs,
                    timestamp = timestamp,
                    sequenceId = seqId,
                    eventId = subtitleEvent.eventId,
                    sessionEpoch = entryEpoch
                )
                onDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(dialogueToTranslate, translatedText, logStatus)
                    }
                }
                onAlignedDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(subtitleEvent, translatedText, logStatus)
                    }
                }
            }

            is DubbingEnqueueOutcome.Queued -> {
                logStatus = "Queued (${outcome.queueSize})"
                TranslatorStateRepository.updateQueueTelemetry(queuedCount = outcome.queueSize)
                TranslatorStateRepository.recordTranslationResult(
                    english = dialogueToTranslate,
                    hindi = translatedText,
                    wasSpoken = false,
                    skippedReason = "Queued next (${outcome.queueSize})",
                    processingTimeMs = elapsedMs,
                    timestamp = timestamp,
                    sequenceId = seqId,
                    eventId = subtitleEvent.eventId,
                    sessionEpoch = entryEpoch
                )
                onDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(dialogueToTranslate, translatedText, logStatus)
                    }
                }
                onAlignedDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(subtitleEvent, translatedText, logStatus)
                    }
                }
            }

            is DubbingEnqueueOutcome.QueuedAndSkippedStale -> {
                logStatus = if (state.dubbingDeliveryMode == DubbingDeliveryMode.LIVE_MODE &&
                    ttsManager.stopIfSupersededInLiveMode(seqId)
                ) {
                    "Preempted stale speech • Speaking latest"
                } else {
                    "Skipped stale line • Queued (${outcome.queueSize})"
                }
                TranslatorStateRepository.updateQueueTelemetry(
                    queuedCount = outcome.queueSize,
                    skippedRapidIncrement = 1
                )
                TranslatorStateRepository.recordTranslationResult(
                    english = dialogueToTranslate,
                    hindi = translatedText,
                    wasSpoken = false,
                    skippedReason = logStatus,
                    processingTimeMs = elapsedMs,
                    timestamp = timestamp,
                    sequenceId = seqId,
                    eventId = subtitleEvent.eventId,
                    sessionEpoch = entryEpoch
                )
                onDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(dialogueToTranslate, translatedText, logStatus)
                    }
                }
                onAlignedDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(subtitleEvent, translatedText, logStatus)
                    }
                }
                if (state.dubbingDeliveryMode == DubbingDeliveryMode.LIVE_MODE && !isTtsSpeakingNow()) {
                    drainNextQueuedSubtitleIfAny()
                }
            }

            is DubbingEnqueueOutcome.SpeakImmediately -> {
                TranslatorStateRepository.updateQueueTelemetry(queuedCount = 0)
                if (sessionEpoch.get() != entryEpoch || (enforceActiveSession && !TranslatorStateRepository.state.value.isCapturingOcr)) {
                    return "" to ""
                }
                lastSpokenText = translatedText.trim()
                lastExtractedNormalized = SubtitleDubbingQueue.normalize(dialogueToTranslate)
                lastExtractedSpeakerContextKey = candidateSpeakerContextKey

                val spokenSuccess = if (isVoiceMuted) {
                    false
                } else {
                    speakHindiNonBlocking(
                        hindiText = translatedText,
                        forceSpeakEvenIfRepeat = false,
                        voiceProfile = assignedVoice,
                        sourceEnglishText = dialogueToTranslate,
                        characterAssignment = parsedDialogue.characterAssignment,
                        routeDecision = finalRouteDecision,
                        sequenceId = seqId,
                        subtitleEventId = subtitleEvent.eventId,
                        frameTimestampMs = frameTimestampMs
                    )
                }
                val genderBadge = parsedDialogue.detectedGender.displayLabel
                logStatus = when {
                    isVoiceMuted -> "Voice Muted • $speakerTag ($genderBadge)"
                    spokenSuccess -> "Speaking ${targetLang.displayName} ($speakerTag)"
                    else -> "TTS Initializing"
                }

                TranslatorStateRepository.recordTranslationResult(
                    english = dialogueToTranslate,
                    hindi = translatedText,
                    wasSpoken = spokenSuccess,
                    skippedReason = logStatus,
                    processingTimeMs = elapsedMs,
                    timestamp = timestamp,
                    sequenceId = seqId,
                    eventId = subtitleEvent.eventId,
                    sessionEpoch = entryEpoch
                )

                onDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(dialogueToTranslate, translatedText, logStatus)
                    }
                }
                onAlignedDebugTextUpdate?.let { cb ->
                    pipelineScope.launch(Dispatchers.Main) {
                        cb(subtitleEvent, translatedText, logStatus)
                    }
                }
            }
        }

        TranslatorStateRepository.appendAlignmentLog(
            SubtitleAlignmentLogEntry(
                sequenceId = seqId,
                eventId = subtitleEvent.eventId,
                speakerLabel = speakerTag,
                speakerId = resolvedSid,
                rawEnglish = dialogueToTranslate,
                translatedHindi = translatedText,
                translationStyle = state.translationStyle.shortBadge,
                deliveryMode = state.dubbingDeliveryMode.shortBadge,
                status = logStatus,
                endToEndLatencyMs = (System.currentTimeMillis() - frameTimestampMs).coerceAtLeast(elapsedMs)
            )
        )

        return dialogueToTranslate to translatedText
    }

    private fun drainNextQueuedSubtitleIfAny() {
        val drainEpoch = sessionEpoch.get()
        pipelineScope.launch(Dispatchers.Main) {
            if (sessionEpoch.get() != drainEpoch || !TranslatorStateRepository.state.value.isCapturingOcr) {
                dubbingQueue.clear()
                TranslatorStateRepository.updateQueueTelemetry(queuedCount = 0)
                return@launch
            }
            val next = dubbingQueue.pollNext() ?: run {
                TranslatorStateRepository.updateQueueTelemetry(queuedCount = 0)
                return@launch
            }
            val state = TranslatorStateRepository.state.value
            TranslatorStateRepository.updateQueueTelemetry(queuedCount = dubbingQueue.size())
            if (state.isVoiceMuted) return@launch

            lastSpokenText = next.translatedText.trim()
            lastExtractedNormalized = SubtitleDubbingQueue.normalize(next.spokenDialogue)
            lastExtractedSpeakerContextKey = "${next.buildSpeakerContextKey()}:${state.translationStyle.code}:${state.targetLanguage.code}"

            val spokenSuccess = speakHindiNonBlocking(
                hindiText = next.translatedText,
                forceSpeakEvenIfRepeat = true,
                voiceProfile = next.voiceProfile,
                sourceEnglishText = next.sourceEnglish,
                characterAssignment = next.characterAssignment,
                routeDecision = next.routeDecision,
                sequenceId = next.sequenceId,
                subtitleEventId = next.eventId,
                frameTimestampMs = next.frameTimestampMs
            )

            TranslatorStateRepository.recordTranslationResult(
                english = next.spokenDialogue,
                hindi = next.translatedText,
                wasSpoken = spokenSuccess,
                skippedReason = if (spokenSuccess) "Spoken from queue (${next.speakerLabel})" else "Queue TTS failed",
                processingTimeMs = 0L,
                timestamp = timeFormatter.format(Date()),
                sequenceId = next.sequenceId,
                eventId = next.eventId,
                sessionEpoch = drainEpoch
            )
        }
    }

    suspend fun translateEnglishToHindi(
        englishText: String,
        speakerName: String? = null
    ): String = translateEnglishToHindiDetailed(englishText, speakerName).translatedText

    suspend fun translateEnglishToHindiDetailed(
        englishText: String,
        speakerName: String? = null,
        translationStyle: TranslationStyle = TranslatorStateRepository.state.value.translationStyle,
        gameNamespace: String = VoiceProfileRepository.getActiveGameNamespace()
    ): DetailedTranslationResult = withContext(Dispatchers.IO) {
        val state = TranslatorStateRepository.state.value
        HindiTranslationEngine.translateSuspendDetailed(
            englishText = englishText,
            targetLanguage = state.targetLanguage,
            mode = state.translationMode,
            speakerName = speakerName,
            translationStyle = translationStyle,
            gameNamespace = gameNamespace
        )
    }

    /**
     * Applies configured [PronunciationGlossary] rules right before speaking via [ForegroundTtsManager]
     * so English names and Hinglish terms sound natural without altering displayed Hindi captions.
     */
    fun speakHindiNonBlocking(
        hindiText: String,
        forceSpeakEvenIfRepeat: Boolean = false,
        voiceProfile: VoiceProfile? = null,
        sourceEnglishText: String = "",
        characterAssignment: com.example.data.CharacterVoiceAssignment? = null,
        routeDecision: VoiceRouteDecision? = null,
        sequenceId: Long = 0L,
        subtitleEventId: String = "",
        frameTimestampMs: Long = 0L
    ): Boolean {
        if (hindiText.isBlank()) return false
        val state = TranslatorStateRepository.state.value
        if (!forceSpeakEvenIfRepeat && state.isVoiceMuted) {
            return false
        }
        lastSpokenText = hindiText.trim()
        val speechReadyText = if (state.targetLanguage.code == "hi") {
            PronunciationGlossary.applyForSpeech(hindiText, state.pronunciationGlossary)
        } else {
            hindiText
        }
        val activeProfile = routeDecision?.voiceProfile
            ?: voiceProfile
            ?: VoiceProfileRepository.voices.value.find {
                it.id == VoiceProfileRepository.selectedVoiceId.value
            }
        return ttsManager.speakNonBlocking(
            text = speechReadyText,
            voiceProfile = activeProfile,
            sourceEnglishText = sourceEnglishText,
            characterAssignment = routeDecision?.characterAssignment ?: characterAssignment,
            routeDecision = routeDecision,
            sequenceId = sequenceId,
            subtitleEventId = subtitleEventId,
            frameTimestampMs = frameTimestampMs,
            deliveryMode = state.dubbingDeliveryMode
        )
    }

    fun previewVoiceProfile(voiceProfile: VoiceProfile) {
        val lang = TranslatorStateRepository.state.value.targetLanguage
        val previewLine = when (lang.code) {
            "hi" -> "हे गेमर! यह ${voiceProfile.name} की आवाज़ है। गेम के डायलॉग इसी आवाज़ में बोले जाएंगे।"
            else -> lang.sampleGreeting
        }
        ttsManager.speakNonBlocking(previewLine, voiceProfile = voiceProfile)
    }

    fun resetAntiRepeatMemory() {
        stopAndClearQueue()
        CharacterVoiceRouter.resetContinuationContext()
        imageProcessor.resetFrameDiffCache()
        HindiTranslationEngine.clearSceneContext()
        lastSpokenText = ""
        lastExtractedNormalized = ""
        lastExtractedSpeakerContextKey = ""
        TranslatorStateRepository.clearLastSpokenMemory()
    }

    private fun buildSpeakerContextAntiRepeatKey(
        routeDecision: VoiceRouteDecision?,
        characterAssignment: com.example.data.CharacterVoiceAssignment?,
        speakerName: String?,
        epoch: Long
    ): String {
        val ns = (routeDecision?.gameNamespace
            ?: characterAssignment?.gameNamespace
            ?: VoiceProfileRepository.getActiveGameNamespace()).lowercase(Locale.ROOT)
        val speakerIdentity = routeDecision?.antiRepeatSpeakerIdentity
            ?: "$ns:${characterAssignment?.characterName ?: com.example.data.CharacterVoiceAssignment.normalizeName(speakerName ?: "unknown")}"
        return "$speakerIdentity:ep$epoch"
    }

    fun promptInstallHindiTtsData(context: Context, openSystemInstaller: Boolean = true) {
        ttsManager.requestAsyncLanguageDataDownload(
            context = context,
            openSystemInstaller = openSystemInstaller
        )
    }

    private fun cleanExtractedSubtitle(rawText: String): String {
        return rawText
            .lines()
            .map { it.trim() }
            .filter { it.length >= 2 }
            .joinToString(" ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
